#include <string>
using namespace std;
string GetHello();
string GetAdressat(string adressat);