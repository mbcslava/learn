#include "stdafx.h"
#include "HelloFunction.h"

string GetHello()
{
	return "Hello";
}

string GetAdressat(string adressat)
{
	return adressat;
}